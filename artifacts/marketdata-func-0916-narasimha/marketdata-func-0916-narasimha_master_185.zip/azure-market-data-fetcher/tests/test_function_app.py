import importlib
import logging
import os
import sys
import time
from datetime import datetime, timedelta

import brokers.broker_data_manager as bdm
from utils.cache_utils import is_test_blob_path, test_blob_name as build_test_blob_name
from utils.env_config import EnvConfig
from utils.shared_cache import EXPIRIES_CACHE

def setupDependencies(monkeypatch, minutes: int = 1):
    """Arrange and return the loaded `function_app` module with TEST_MODE enabled.

    This mirrors the agent guideline's `setupDependencies()` pattern used for
    repeatable test setup. It sets environment vars and imports/reloads the
    module so the module-level startup window is initialised.
    """
    repo_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if repo_path not in sys.path:
        sys.path.insert(0, repo_path)

    monkeypatch.setenv("TEST_MODE", "true")
    monkeypatch.setenv("TEST_MODE_MINUTES", str(minutes))

    for mod_name in ("function_app", "app_settings"):
        if mod_name in sys.modules:
            del sys.modules[mod_name]
    function_app = importlib.import_module("function_app")
    importlib.reload(function_app)
    return function_app


def test_test_mode_window_resets_on_reload(monkeypatch):
    # Arrange
    fa = setupDependencies(monkeypatch, minutes=1)

    # Assert: startup window exists and includes 'now'
    ist_now = datetime.now(fa.IST_TZ)
    # Use EnvConfig-backed test-mode window state (keeps tests independent
    # of module-level implementation details).
    assert EnvConfig._TEST_MODE_START is not None
    assert EnvConfig.get_test_mode_expiry() is not None
    # The startup start should be <= now <= expiry
    assert EnvConfig._TEST_MODE_START <= ist_now <= EnvConfig.get_test_mode_expiry()

    # Act: simulate expiry by moving expiry to 1 second after start
    EnvConfig._TEST_MODE_EXPIRY = EnvConfig._TEST_MODE_START + timedelta(seconds=1)
    # Assert: simulated time after expiry returns inactive
    sim_now = EnvConfig._TEST_MODE_START + timedelta(seconds=2)
    assert not EnvConfig.is_test_mode_active(sim_now)

    # Act: simulate host restart (reload module)
    for mod_name in ("function_app", "app_settings"):
        if mod_name in sys.modules:
            del sys.modules[mod_name]
    fa2 = importlib.import_module("function_app")
    importlib.reload(fa2)

    # Assert: after reload the TEST_MODE window is reset into the future
    now2 = datetime.now(fa2.IST_TZ)
    assert EnvConfig._TEST_MODE_START is not None
    assert EnvConfig.get_test_mode_expiry() is not None
    assert now2 <= EnvConfig.get_test_mode_expiry()


def test_test_mode_uses_all_days_schedule(monkeypatch):
    fa = setupDependencies(monkeypatch, minutes=5)

    assert fa.DYNAMIC_OPTION_CHAIN_CRON.split(" ")[-1] == "*"


def test_daily_timer_runs_on_startup_in_test_mode(monkeypatch):
    fa = setupDependencies(monkeypatch, minutes=5)
    functions = {function.get_function_name(): function for function in fa.app.get_functions()}
    daily_binding = functions["daily_job"].get_bindings_dict()["bindings"][0]

    assert daily_binding["runOnStartup"] is True


def test_option_chain_test_path_routes_to_test_container(monkeypatch):
    local_path = "/tmp/test_mode_data/market_data_cache/option_chain/underlying=NSE%3ANIFTY50-INDEX/part-0.parquet"
    blob_name = "option_chain/underlying=NSE%3ANIFTY50-INDEX/part-0.parquet"
    # Ensure TEST_MODE is enabled for this check
    monkeypatch.setenv("TEST_MODE", "true")
    assert is_test_blob_path(local_path, is_local=False)
    assert build_test_blob_name(blob_name) == "market_data_cache/option_chain/underlying=NSE%3ANIFTY50-INDEX/part-0.parquet"


def test_test_mode_completion_logged_once(monkeypatch, caplog):
    fa = setupDependencies(monkeypatch, minutes=5)
    expired_at = EnvConfig.get_test_mode_expiry()
    now = expired_at + timedelta(seconds=1)

    with caplog.at_level(logging.INFO):
        assert not EnvConfig.is_test_mode_active(now)
        assert not EnvConfig.is_test_mode_active(now + timedelta(minutes=1))

    completion_logs = [record for record in caplog.records if "TEST_MODE window completed" in record.message]
    assert len(completion_logs) == 1


def test_daily_prefetch_populates_expiries_cache(monkeypatch):
    fa = setupDependencies(monkeypatch, minutes=5)

    # Use a small, controlled symbol list and fake manager to avoid external calls.
    # DailyScheduler reads symbols via EnvConfig, so override it there (not on `fa`).
    monkeypatch.setitem(EnvConfig._overrides, "OPTION_CHAIN_SYMBOLS", "NSE:TEST-EQ")

    class FakeManager:
        def get_expiries(self, instrument):
            return ["2026-09-30"]

        def get_expiry_dates(self, instrument):
            return []

        def get_option_chain(self, *args, **kwargs):
            return []

    fake_instrument = type("Instr", (), {"symbol": "NSE:TEST-EQ"})()

    # Patch resolver and preferred brokers to use our fake objects
    monkeypatch.setattr(bdm.InstrumentResolver, "resolve", staticmethod(lambda s: fake_instrument))
    monkeypatch.setattr(bdm.PreferredBrokers, "managers", staticmethod(lambda: {"fyers": FakeManager()}))

    # Clear cache, run daily prefetch, and validate cache populated
    EXPIRIES_CACHE.clear()
    fa.DailyScheduler().run()

    today = datetime.now(fa.IST_TZ).strftime("%Y-%m-%d")
    cache_key = ("fyers", "NSE:TEST-EQ", today)
    assert cache_key in EXPIRIES_CACHE
    assert isinstance(EXPIRIES_CACHE[cache_key], list)


def test_daily_prefetch_logs_warning_when_no_expiries(monkeypatch, caplog):
    fa = setupDependencies(monkeypatch, minutes=5)

    # DailyScheduler reads symbols via EnvConfig, so override it there (not on `fa`).
    monkeypatch.setitem(EnvConfig._overrides, "OPTION_CHAIN_SYMBOLS", "NSE:EMPTY-EQ")

    class EmptyManager:
        def get_expiries(self, instrument):
            return []

        def get_expiry_dates(self, instrument):
            return []

        def get_option_chain(self, *args, **kwargs):
            return []

    fake_instrument = type("Instr", (), {"symbol": "NSE:EMPTY-EQ"})()
    monkeypatch.setattr(bdm.InstrumentResolver, "resolve", staticmethod(lambda s: fake_instrument))
    monkeypatch.setattr(bdm.PreferredBrokers, "managers", staticmethod(lambda: {"fyers": EmptyManager()}))

    EXPIRIES_CACHE.clear()
    with caplog.at_level(logging.WARNING):
        fa.DailyScheduler().run()

    warnings = [r for r in caplog.records if "expiries not resolved during pre-market prefetch" in r.message]
    assert len(warnings) >= 1


def test_live_scheduler_fetches_batch_concurrently(monkeypatch):
    """A PARALLEL_BATCH_SIZE (5) symbol batch should be fetched concurrently,
    not one-by-one, so the broker sees ~5 overlapping calls within the same
    second instead of 5 calls spread out sequentially.
    """
    fa = setupDependencies(monkeypatch, minutes=5)

    symbols = [f"NSE:SYM{i}-EQ" for i in range(5)]
    fa.OPTION_CHAIN_SYMBOLS = symbols

    call_starts: list[float] = []
    call_delay = 0.2

    class SlowManager:
        def get_expiries(self, instrument):
            return ["2026-09-30"]

        def get_option_chain(self, instrument, strikecount=10, expiries=None):
            call_starts.append(time.monotonic())
            time.sleep(call_delay)
            return {"data": {}}

    monkeypatch.setattr(bdm.InstrumentResolver, "resolve", staticmethod(lambda s: type("Instr", (), {"symbol": s})()))
    monkeypatch.setattr(bdm.PreferredBrokers, "managers", staticmethod(lambda: {"fyers": SlowManager()}))
    monkeypatch.setattr(bdm.ExpiryResolver, "resolve_range", staticmethod(lambda expiries, weeks, months: ["2026-09-30"]))

    EXPIRIES_CACHE.clear()

    start = time.monotonic()
    fa.LiveScheduler(max_concurrency=5).run(symbols=symbols)
    elapsed = time.monotonic() - start

    assert len(call_starts) == 5
    # Sequential would take ~5 * call_delay; concurrent stays close to one call_delay.
    assert elapsed < call_delay * len(symbols)
    # All 5 calls should have started within the same short window (i.e. "same second"),
    # not staggered call_delay apart from each other.
    assert max(call_starts) - min(call_starts) < call_delay

