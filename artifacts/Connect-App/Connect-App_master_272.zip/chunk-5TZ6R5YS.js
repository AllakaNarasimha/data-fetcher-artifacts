import{h as a}from"./chunk-WRNVZS7Z.js";import"./chunk-UMXOXOAI.js";export{a as HealthStatusComponent};
