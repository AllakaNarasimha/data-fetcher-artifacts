import{h as a}from"./chunk-KLHBLPP5.js";import"./chunk-XG4VA7UQ.js";export{a as HealthStatusComponent};
