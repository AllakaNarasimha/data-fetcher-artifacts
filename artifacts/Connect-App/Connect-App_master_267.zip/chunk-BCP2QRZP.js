import{h as a}from"./chunk-Z4TBMAIK.js";import"./chunk-PFIUKLOQ.js";export{a as HealthStatusComponent};
