import{h as a}from"./chunk-JO5RHLJC.js";import"./chunk-PFIUKLOQ.js";export{a as HealthStatusComponent};
