import{a}from"./chunk-2F7DBLH3.js";import"./chunk-FU6VSFYF.js";export{a as HealthStatusComponent};
