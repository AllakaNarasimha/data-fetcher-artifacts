import{h as a}from"./chunk-HDTNRQYD.js";import"./chunk-PFIUKLOQ.js";export{a as HealthStatusComponent};
