import{h as a}from"./chunk-LUK52LUH.js";import"./chunk-PFIUKLOQ.js";export{a as HealthStatusComponent};
